package org.springboot.dubbo.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springboot.dubbo.service.UserService;
import org.springboot.dubbo.user.User;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Service;

//@Service是dubbo的service注解，表示发布服务，不具备spring的@service注解的功能
//@Service用于标注对外暴露的dubbo接口实现类，若使用的是dubbo的Service注解时，在controller注入的时候，要选择@Reference注解来进行注入
//@Service注解表示dubbo提供者服务用于声明对外暴露服务,version：指定服务的版本号
@Service(version = "1.0.0") 
@Component
public class UserServiceImpl implements UserService {

	public List<User> getAllUsers() {
		List<User> users = new ArrayList<User>();
		for (int i = 0; i < 20; i++) {
			User user = new User("username" + i, "password" + i);
			//add()方法是向列表的末尾插入新元素，作为一个对象
			users.add(user);
		}

		return users;
	}
}