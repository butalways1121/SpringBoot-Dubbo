package org.springboot.dubbo;

import java.util.List;

import org.springboot.dubbo.controller.UserController;
import org.springboot.dubbo.user.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.alibaba.dubbo.spring.boot.annotation.EnableDubboConfiguration;

@SpringBootApplication
@EnableDubboConfiguration
public class DubboClientApplication {
	public static void main(String[] args) {
		// 入口运行类
		//启动嵌入式的 Tomcat 并初始化 Spring 环境及其各 Spring 组件
		ConfigurableApplicationContext run = SpringApplication.run(DubboClientApplication.class, args);
		System.out.println("DubboClient启动成功。。。");
		//利用类型返回IOC容器的bean,但要求IOC容器中,必须只能有一个该类型的bean
		UserController bean = run.getBean(UserController.class);
		List<User> allUsers = bean.getAllUsers();
		for(User user:allUsers) {
			System.out.println("用户名:"+user.getUserName()+"密码:"+user.getPassword());
		}
	}
}
