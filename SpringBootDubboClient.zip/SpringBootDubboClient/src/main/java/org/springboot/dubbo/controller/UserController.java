package org.springboot.dubbo.controller;

import java.util.List;

import org.springboot.dubbo.service.UserService;
import org.springboot.dubbo.user.User;
import org.springframework.stereotype.Controller;

import com.alibaba.dubbo.config.annotation.Reference;

@Controller
public class UserController {
	//@Reference 用于dubbo消费者服务指明引用哪个提供者接口服
	@Reference(version = "1.0.0")
	UserService userService;

	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}
}
