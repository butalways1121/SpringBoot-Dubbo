package org.springboot.dubbo.service;

import java.util.List;

import org.springboot.dubbo.user.User;

public interface UserService {
	List<User> getAllUsers();
}
